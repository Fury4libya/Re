This script can get up to 5000 TikTok followers per user!

## How to get TikTok API Followers

- Git-clone this repo!
- Get your API key here: [https://rapidapi.com/SteveJobsnihack/api/scraptubes](https://rapidapi.com/SteveJobsnihack/api/scraptubes)
- Update app.py with your API key
- Run the .py file!

### Notes:

You can get only up to 5K followers per user (TikTok limit)!!!
